###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  projdir <- args[1]
  output_file <- args[2]
  
  mort_input <- args[3]
  trans_input <- args[4]
  income_input <- args[5]
} else {
  projdir <- Sys.getenv(c("Longevity"))
  output_file <- paste(projdir,"/processed/fem/income_epv.csv",sep="")
  
  mort_input <-  paste(projdir,"/processed/fem/baseline_cohort_mortality.csv",sep="")
  trans_input <- paste(projdir,"/processed/fem/baseline_cohort_transitions.csv",sep="")
  income_input <- paste(projdir,"/processed/fem/income.csv",sep="")
}

workdir <- paste(projdir,"/scripts/programs/model-baseline",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

intr   <- 0.03

data_mort <-  read.csv(mort_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_inc <-  read.csv(income_input,header = TRUE)

min_age <- min(data_mort$age)
max_age <- max(data_mort$age)
n_ages  <- max_age - min_age + 1

min_state <- min(data_mort$health_state) #should always be 1
max_state <- max(data_mort$health_state)
n_states  <- max_state + 1 - min_state

# Initialize and fill in matrices
mortality  <- matrix(0, nrow = n_states, ncol = n_ages)
transition <- array(0,dim=c(n_states, n_ages,n_states))
income <- matrix(0, nrow = n_states, ncol = n_ages)
rates      <- matrix(0, nrow = n_states, ncol = n_ages)

for (i in 1:n_ages){
  for (j in  1:n_states){
    mortality[j,i] <- data_mort[(j-1)*n_ages + i,3]
    income[j,i] <- data_inc[(j-1)*n_ages + i,3]
    for (k in 1:n_states){
      transition[j,i,k] <- data_trans[(j-1)*n_ages + i,2+k]
    }
  }
}


####
# Calculate expected present value of future income, by age and state
####

EPV_FutInc  <- matrix(0, nrow = n_states, ncol = n_ages)
EPV_FutInc[,n_ages] = income[,n_ages]

for (i in 1:(n_ages-1)){
  for (j in  1:n_states){
    temp = 0
    for(k in 1:n_states){
      temp = temp + transition[j,n_ages-i,k] * EPV_FutInc[k,n_ages-i+1] * exp(-intr)
    }
    EPV_FutInc[j,n_ages-i] = income[j,n_ages] + (1 - mortality[j,n_ages-i]) * temp
  }
}

write.csv(EPV_FutInc, output_file)


  