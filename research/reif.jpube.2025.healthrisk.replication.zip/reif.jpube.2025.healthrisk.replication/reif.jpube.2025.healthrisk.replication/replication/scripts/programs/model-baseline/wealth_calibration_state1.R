###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  target_vsl <- as.numeric(args[1])
  projdir <- args[2]
  output_file <- args[3]
  
  mort_input <- args[4]
  qual_input <- args[5]
  trans_input <- args[6]
  rates_input <- args[7]
  
  gamma <- as.numeric(c(args[8]))
} else {
  target_vsl <- 6000000
  projdir <- Sys.getenv(c("Longevity"))
  output_file <- paste(projdir,"/results/intermediate/output.csv",sep="")
  
  mort_input <-  paste(projdir,"/processed/fem/baseline_cohort_mortality.csv",sep="")
  qual_input <-  paste(projdir,"/processed/fem/baseline_cohort_quality.csv",sep="")
  trans_input <- paste(projdir,"/processed/fem/baseline_cohort_transitions.csv",sep="")
  rates_input <- paste(projdir,"/processed/fem/baseline_cohort_oopmd_return.csv",sep="")
  
  gamma <- 1.25
}

# Load packages
library(rootSolve)

workdir <- paste(projdir,"/scripts/programs/model-baseline",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################
set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth (seed)
w_0    <- 100000


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")

# Solve for initial wealth
fun <- function (x) calcVSL(50,1,x) - target_vsl
target_wealth <- uniroot(fun, c(w_0, 2600000))$root

print("")
print(paste("When wealth is set equal to ",round(target_wealth)," then VSL at age 50 in state 1 is ",round(calcVSL(50,1,target_wealth)),sep=""))

write.csv(target_wealth, file = output_file)


