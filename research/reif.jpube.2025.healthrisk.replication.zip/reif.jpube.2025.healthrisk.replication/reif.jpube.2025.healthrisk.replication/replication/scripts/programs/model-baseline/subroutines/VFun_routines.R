calcVFun <- function(init_age,init_state,wealth){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myret <- optimalK[init_state + (min_state - 1),(init_age-min_age) + 1] * wealth^(1-ourgamma) - subslevel^(1-ourgamma) * (calcQualAdjLE(init_age,init_state,intrho))
  myret <- myret / (1-ourgamma)
  return(myret)
}

calcVPrime <- function(init_age,init_state,wealth){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myret <- optimalK[init_state + (min_state - 1),(init_age-min_age) + 1] * wealth^(-ourgamma) 
  return(myret)
}