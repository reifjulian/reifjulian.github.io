# EVALUATING RANGES
min_age <- min(data_mort$age)
max_age <- max(data_mort$age)
n_ages  <- max_age - min_age + 1

min_state <- min(data_mort$health_state) #should always be 1
max_state <- max(data_mort$health_state)
n_states  <- max_state + 1 - min_state

# CREATING MATRICES WITH QUANTITIES
mortality  <- matrix(0, nrow = n_states, ncol = n_ages)
quality    <- matrix(0, nrow = n_states, ncol = n_ages)
transition <- array(0,dim=c(n_states, n_ages,n_states))
rates      <- array(0,dim=c(n_states, n_ages,n_states))

for (i in 1:n_ages){
  for (j in  1:n_states){
    mortality[j,i] <- data_mort[(j-1)*n_ages + i,3]
    quality[j,i]   <- data_qual[(j-1)*n_ages + i,3]
    for (k in 1:n_states){
      transition[j,i,k] <- data_trans[(j-1)*n_ages + i,2+k]
      rates[j,i,k]    <- data_rates[(j-1)*n_ages + i,2+k]
    }
  }
}




