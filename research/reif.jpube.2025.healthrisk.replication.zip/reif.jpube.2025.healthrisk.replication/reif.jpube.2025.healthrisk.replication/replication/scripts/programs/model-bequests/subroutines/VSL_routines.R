calcVSL <- function(init_age,init_state,wealth){
  VSL <- 0
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intr   <- 0.03
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  norm_term <- bequest[init_state + (min_state - 1),(init_age-min_age) + 1] * (wealth^(1-ourgamma) - subslevel^(1-ourgamma))/(1-gamma) 
  return((calcVFun(init_age,init_state,wealth) - norm_term)/calcVPrime(init_age,init_state,wealth))
  
}

calcVSI <- function(init_age,fromstate,tostate,wealth){
  
  hlp <- calcVFun(init_age,fromstate,wealth)-calcVFun(init_age,tostate,wealth*exp(rates[fromstate + (min_state - 1),(init_age-min_age) + 1, tostate + (min_state - 1)]-rates[fromstate + (min_state - 1),(init_age-min_age) + 1, fromstate + (min_state - 1)]))
  hlp <- hlp/calcVPrime(init_age,fromstate,wealth)
  return(hlp)
  
}