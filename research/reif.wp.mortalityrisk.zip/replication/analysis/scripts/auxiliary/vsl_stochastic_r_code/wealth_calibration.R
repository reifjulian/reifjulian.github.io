rm (list = ls())

###############################################################################
# Parse command-line arguments
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# Parse arguments
args <- commandArgs(trailingOnly = TRUE)
if (length(args)) {
  projdir <- c(args[1])
  target_vsl <- as.numeric(c(args[2]))  
} else {

  projdir <- file.path("C:/Users/mypath")
  target_vsl <- 5350000
}

###############################################################################
# Install (if necessary) and load necessary packages
###############################################################################
# Install new packages to first element of .libPaths(). If this path is not writeable (e.g. after a fresh installation of R), install to default user library path
lib <- .libPaths()[1]
if (!dir.create(lib, showWarnings = FALSE)[1]) {
  lib <- Sys.getenv("R_LIBS_USER")
  dir.create(lib, showWarnings = FALSE)
}

# Select repository for downloading new R packages
repos <- "http://cran.us.r-project.org"

# Specify packages to load, installing as needed
packages <- c("rootSolve")
installed <- packages %in% installed.packages()[, "Package"]
invisible(lapply(packages[!installed], install.packages, lib = lib, repos = repos, dependencies=TRUE))
suppressMessages(invisible(lapply(packages, library, character.only=TRUE)))

# Load packages
library(rootSolve)

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/analysis/scripts/auxiliary/vsl_stochastic_r_code",sep="")
inputdir  = paste(projdir,"/analysis/data/proc/fem",sep="")

setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth (seed)
w_0    <- 780363


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(paste(inputdir,"/onestate/baseline_cohort_mortality_one_state.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/onestate/baseline_cohort_quality_one_state.csv",sep=""),header = TRUE)
data_trans <- read.csv(paste(inputdir,"/onestate/transitions_one_state.csv",sep=""),header = TRUE)
data_rates <- read.csv(paste(inputdir,"/onestate/returns_one_state.csv",sep=""),header = TRUE)


# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")

# Solve for initial wealth
fun <- function (x) calcVSL(50,1,x) - target_vsl
target_wealth <- uniroot(fun, c(w_0, 900000))$root

print("")
print(paste("When wealth is set equal to ",round(target_wealth)," then VSL at age 50 is ",round(calcVSL(50,1,target_wealth)),sep=""))
stopifnot( abs(target_wealth-862947)<1 )

