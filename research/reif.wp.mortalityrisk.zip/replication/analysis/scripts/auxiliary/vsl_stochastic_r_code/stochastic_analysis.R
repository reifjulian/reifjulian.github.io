rm (list = ls())

###############################################################################
# SETUP: parse command-line arguments, and load necessary packages
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# If called from command line, store the relevant arguments
print("Args:")
(args <- commandArgs(trailingOnly = TRUE))
if (length(args)) {
	projdir <- c(args[1])
	initial_wealth <- as.numeric(c(args[2]))

} else {

	# Else, script is being run interactively and user must define variables here. Note that projdir (path to project directory) must be set below.
	projdir <- file.path("C:/Users/mypath")
	initial_wealth <- 862947
}

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/analysis/scripts/auxiliary/vsl_stochastic_r_code",sep="")
inputdir  = paste(projdir,"/analysis/data/proc/fem",sep="")
outputdir = paste(projdir,"/analysis/results/intermediate_files/stochastic",sep="")

setwd(workdir)


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth
w_0 <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(paste(inputdir,"/baseline_cohort_mortality.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/baseline_cohort_quality.csv",sep=""),header = TRUE)
data_trans <- read.csv(paste(inputdir,"/baseline_cohort_transitions.csv",sep=""),header = TRUE)
data_rates <- read.csv(paste(inputdir,"/baseline_cohort_nospend_return.csv",sep=""),header = TRUE)


# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")


#####
# Descriptive statistics: LE by health state, for different ages
#####
LEvec50 <- rep(0,n_states)
LEvec75 <- rep(0,n_states)
for (i in 1:n_states){
	LEvec50[i] <- calcLE(50,i)
	LEvec75[i] <- calcLE(75,i)
}
write.csv(t(rbind(LEvec50,LEvec75)), file = paste(outputdir,"/LE_summary.csv",sep=""))


#####
# Consumption and VSL when in health state 1 for all ages (ie healthy, no shocks) - not currently used
#####
#healthypath           <- rep(1,max_age - age + 1)
#ConsAndVSLpathHealthy <- calcPATH(50,healthypath,w_0)
#plot(ConsAndVSLpathHealthy[1,1:50])
#plot(ConsAndVSLpathHealthy[2,1:50])
#plot(ConsAndVSLpathHealthy[3,1:50])
#write.csv(t(ConsAndVSLpathHealthy), file = "output/c_vsl_w_healthy.csv")


#####
# VSL simulations
#####
# Syntax: simVSL(NSIMS, age_init, state_init, wealth, type), where type is: 1=consumption, 2=VSL (default), and 3=wealth
print("Running VSL simulations...")
set.seed(42)
NSIMS <-10000
myVSLs <- simVSL(NSIMS,50,1,w_0)
write.csv(t(myVSLs), file = paste(outputdir,"/sims_VSL.csv",sep=""))


#####
# VSL vs VSI at age 50
#####

age <- 50

LEvec  <- rep(0,n_states)
DLEvec <- rep(0,n_states)
VSLvec <- rep(0,n_states)
VSIvec <- rep(0,n_states)

for (i in 1:n_states){
	LEvec[i] <- calcLE(age,i)
	#DLEvec[i] <- calcLE(age,i,intr)
	VSLvec[i] <- calcVSL(age,i,w_0)
	VSIvec[i] <- calcVSI(age,1,i,w_0)
}
write.csv(t(rbind(LEvec,VSLvec,VSIvec)), file = paste(outputdir,"/vsl_vsi_age50.csv",sep=""))



###
# Consumption and VSL for person sufferring two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 14 for remaining years
###

# "The first shock reduces her life expectancy by 3.0 years"
# "The second one reduces her life expectancy by 6.8 years"
# "The FEM estimates that life expectancy for this sick patient is 8.0 years at age 70"
stopifnot( abs(calcLE(60,1)-calcLE(60,6) - 3.037016)<0.0001 )
stopifnot( abs(calcLE(70,6)-calcLE(70,14) - 6.830474)<0.0001 )
stopifnot( abs(calcLE(70,14) - 8.005162)<0.0001 )

#
healthypath <- c(rep(1,10),rep(6,(max_age - age + 1)-10))
sickpath    <- c(rep(1,10),rep(6,10),rep(14,(max_age - age + 1)-10-10))

#ConsAndVSLpathSick  <- calcPATH(50,sickpath,w_0)
#plot(ConsAndVSLpathSick[2,1:50],type = "l")



slist <- c("_nospend", "_oopmd", "_s14age70")
for (scen in slist) {

	# LOAD DATA
	data_mort <-  read.csv(paste(inputdir,"/baseline_cohort_mortality.csv",sep=""),header = TRUE)
	data_qual <-  read.csv(paste(inputdir,"/baseline_cohort_quality.csv",sep=""),header = TRUE)
	data_trans <- read.csv(paste(inputdir,"/baseline_cohort_transitions.csv",sep=""),header = TRUE)
	data_rates <- read.csv(paste(inputdir,"/baseline_cohort",scen,"_return.csv",sep=""),header = TRUE)

	source("VSL_data_init.R")
	source("VSL_solution_init.R")

	source("VSL_routines.R")
	source("LE_routines.R")
	source("VFun_routines.R")
	source("Path_routines.R")
	source("Sim_routines.R")

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0)
	write.csv(t(ConsAndVSLpathSick), file = paste(outputdir,"/c_vsl_w_health_shock",scen,".csv",sep=""))

	VSLsick = ConsAndVSLpathSick[2,]

	# Calculate VSI (of preventing state 20) for a person who remains in state 2
	# Note: ConsAndVSLpathHealthy and VSLvec below should produce same results
	
	ConsAndVSLpathHealthy  <- calcPATH(50,healthypath,w_0)

	VSLsick <- rep(0,max_age-age+1)
	VSI     <- rep(0,max_age-age+1)

	StateHealthy <- rep(0,max_age-age+1)
	StateSick    <- rep(0,max_age-age+1)
	LEsick       <- rep(0,max_age-age+1)
	LEhealthy    <- rep(0,max_age-age+1)
	for (a in age:max_age){
		
		i = a-age+1
		VSI[i] <- calcVSI(a,healthypath[i],20,ConsAndVSLpathHealthy[3,i])

		StateHealthy[i] <- healthypath[i]
		StateSick[i]    <- sickpath[i]
		LEhealthy[i]    <- calcLE(a,healthypath[i])
		LEsick[i]       <- calcLE(a,sickpath[i])

		# For purposes of comparison
		VSLsick[i] <- calcVSL(a,sickpath[i],ConsAndVSLpathSick[3,i])
	}
	write.csv(t(rbind(StateHealthy,StateSick,LEhealthy,LEsick,VSLsick,VSI)), file = paste(outputdir,"/vsl_vsi_healthshock",scen,".csv",sep=""))
}


#################################################
## COUNTERFACTUAL SCENARIOS 
#################################################

slist <- c("all_cause_mort", "baseline_cohort", "cancre_mort", "hearte_mort")
gammalist <- c(1.5, 2.0, 2.5)
medlist <- c("oopmd","nospend")

for (g in gammalist) {
for (scen in slist) {
for (md in medlist) {
	
	ourgamma  <- g

	# LOAD DATA
	data_mort  <- read.csv(paste(inputdir,"/",scen,"_mortality.csv",sep=""),  header = TRUE)
	data_qual  <- read.csv(paste(inputdir,"/",scen,"_quality.csv",sep=""),    header = TRUE)
	data_trans <- read.csv(paste(inputdir,"/",scen,"_transitions.csv",sep=""),header = TRUE)
	data_rates <- read.csv(paste(inputdir,"/",scen,"_",md,"_return.csv",sep=""),header = TRUE)

	# INITIALIZING DATA AND OPTIMAL SOLUTIONS
	source("VSL_data_init.R")
	source("VSL_solution_init.R")

	# SOURCING ROUTINES
	source("VSL_routines.R")
	source("LE_routines.R")
	source("VFun_routines.R")
	source("Path_routines.R")
	source("Sim_routines.R")


	# Calculate LE, V, and VSL at age 50 for all health states
	LE50     <- rep(0,n_states)
	DLE50    <- rep(0,n_states)
	V50      <- rep(0,n_states)
	VPrime50 <- rep(0,n_states)
	VSL50    <- rep(0,n_states)

	for (j in 1:n_states){
		LE50[j]     <- calcLE(50,j)
		DLE50[j]    <- calcLE(50,j,intr)
		V50[j]      <- calcVFun(50,j,w_0)
		VPrime50[j] <- calcVPrime(50,j,w_0)
		VSL50[j]    <- calcVSL(50,j,w_0)
	}

	# Output results for this scenario
	write.csv(t(rbind(LE50,DLE50,V50,VPrime50,VSL50)), file = paste(outputdir,"/cf_", scen,"_", md,"_", toString(g),".csv",sep=""))
}
}
}

