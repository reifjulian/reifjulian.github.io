rm (list = ls())

###############################################################################
# SETUP: parse command-line arguments, and install necessary packages
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# If called from command line, store the relevant arguments
print("Args:")
(args <- commandArgs(trailingOnly = TRUE))
if (length(args)) {
	projdir <- c(args[1])
	initial_wealth <- as.numeric(c(args[2]))

} else {

	# Else, script is being run interactively and user must define variables here. Note that projdir (path to project directory) must be set below.
	projdir <- file.path("C:/Users/mypath")
}

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/analysis/scripts/auxiliary/vsl_stochastic_r_code_bequests",sep="")
inputdir  = paste(projdir,"/analysis/data/proc/fem",sep="")
outputdir = paste(projdir,"/analysis/results/intermediate_files/stochastic_bequests",sep="")

setwd(workdir)


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth
w_0 <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age

data_mort <-  read.csv(paste(inputdir,"/baseline_cohort_mortality.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/baseline_cohort_quality.csv",sep=""),header = TRUE)
data_trans <- read.csv(paste(inputdir,"/baseline_cohort_transitions.csv",sep=""),header = TRUE)
data_rates <- read.csv(paste(inputdir,"/baseline_cohort_nospend_return.csv",sep=""),header = TRUE)

# EDIT
data_beq   <-  read.csv(paste(inputdir,"/baseline_cohort_bequest.csv",sep=""),header = TRUE)



# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")

###
# Consumption and VSL for person sufferring two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 18 for remaining years
###

# FOR REFERENCE ONLY
#healthypath <- c(rep(1,10),rep(6,(max_age - age + 1)-10))
#sickpath    <- c(rep(1,10),rep(6,10),rep(18,(max_age - age + 1)-10-10))
#ConsAndVSLpathSick  <- calcPATH(50,sickpath,w_0)
#plot(ConsAndVSLpathSick[2,1:50],type = "l")




#################################################
## COUNTERFACTUAL SCENARIOS 
#################################################

slist <- c("all_cause_mort", "baseline_cohort", "cancre_mort", "hearte_mort")
gammalist <- c(1.5, 2.0, 2.5)
medlist <- c("oopmd","nospend")

for (g in gammalist) {
for (scen in slist) {
for (md in medlist) {
	
	ourgamma  <- g

	# LOAD DATA
	data_mort  <- read.csv(paste(inputdir,"/",scen,"_mortality.csv",sep=""),  header = TRUE)
	data_qual  <- read.csv(paste(inputdir,"/",scen,"_quality.csv",sep=""),    header = TRUE)
	data_trans <- read.csv(paste(inputdir,"/",scen,"_transitions.csv",sep=""),header = TRUE)
	data_rates <- read.csv(paste(inputdir,"/",scen,"_",md,"_return.csv",sep=""),header = TRUE)

	# EDIT
	data_beq   <-  read.csv(paste(inputdir,"/",scen,"_bequest.csv",sep=""),  header = TRUE)

	# INITIALIZING DATA AND OPTIMAL SOLUTIONS
	source("VSL_data_init.R")
	source("VSL_solution_init.R")

	# SOURCING ROUTINES
	source("VSL_routines.R")
	source("LE_routines.R")
	source("VFun_routines.R")
	source("Path_routines.R")
	source("Sim_routines.R")


	# Calculate LE, V, and VSL at age 50 for all health states
	LE50     <- rep(0,n_states)
	DLE50    <- rep(0,n_states)
	V50      <- rep(0,n_states)
	VPrime50 <- rep(0,n_states)
	VSL50    <- rep(0,n_states)

	for (j in 1:n_states){
		LE50[j]     <- calcLE(50,j)
		DLE50[j]    <- calcLE(50,j,intr)
		V50[j]      <- calcVFun(50,j,w_0)
		VPrime50[j] <- calcVPrime(50,j,w_0)
		VSL50[j]    <- calcVSL(50,j,w_0)
	}

	# Output results for this scenario
	write.csv(t(rbind(LE50,DLE50,V50,VPrime50,VSL50)), file = paste(outputdir,"/cf_bequests_", scen,"_", md,"_", toString(g),".csv",sep=""))
}
}
}

