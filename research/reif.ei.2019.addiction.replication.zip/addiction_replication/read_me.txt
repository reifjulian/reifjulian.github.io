/////////////////////////////////////
THIS FOLDER CONTAINS REPLICATION CODE FOR THE PAPER:
Julian Reif. "A Model of Addiction and Social Interactions."
/////////////////////////////////////

The Stata script "_run_all.do" produces the tables and figures from the paper.
The script outputs its results to the /results folder.
