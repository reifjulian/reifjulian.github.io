/////////////////////////////////////
THIS FOLDER CONTAINS THE REPLICATION CODE AND DATA FOR THE PAPER:
Malani, Anup, and Julian Reif. "Interpreting pre-trends as anticipation: Impact on estimated treatment effects from tort reform." Journal of Public Economics 124 (2015): 1-17.
/////////////////////////////////////

Note: The physician count data are proprietary and cannot be shared, so the counts have all been set equal to 0 in the dataset provided in this replication folder.
The file provided, "/data/physician_and_laws_replication_censored.dta", can only be used to generate Figure 6 from the table.
However, the code and main results for the other main tables and figures have been provided for completeness.

The Stata script "tables_figures.do" executes the regressions for the main tables and figures in the paper.
The script outputs its results to the /results folder.
Those raw results are organized into the figures and tables from the paper in "Figure 1.xlsx", "Figure 5.xlsx", "Figure 6.xlsx", and "Tables 4-11.xlsx".

The "tables_figures.do" script requires the following add-on Stata modules:
(1) calcpe
(2) xtabond2, modified from the original version to include a new "reverseorthog" option
(3) regsave

The code for all of three of these modules is included in this folder.

Note that xtabond2 is a Mata module that must be compiled in order to be used. In order to do that, open the file "xtabond2.mata" in Stata's do file editor, and run it.
This will generate a new file, "lxtabond2.mlib", which contains the compiled code necessary to run the module.

