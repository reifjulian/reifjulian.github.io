/////////////////////////////////////
THIS FOLDER CONTAINS THE REPLICATION CODE AND DATA FOR THE PAPER:
Huh, Jason, and Julian Reif. "Did Medicare Part D Reduce Mortality?" The Journal of Health Economics 53 (2017): 17-37.
/////////////////////////////////////

The Stata script "tables_figures_mortality.do" produces the tables and figures for the mortality analysis in the paper.
 The Stata script "tables_figures_MEPS.do" produces the tables and figures for the drug use and expenditure analysis in the paper (except for Appendix Table 8, which lists the top three drug treatments for common medical conditions).
These scripts output the results to the /results folder (except for Tables 2 and 6, whose results are available in the Stata output).

NOTE: the outcome variable "yearlydeaths" has been censored in order to comply with NCHS's data use agreement. As a result, the script "tables_figures_mortality.do" will not reproduce the results from the paper.
