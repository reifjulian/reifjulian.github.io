/////////////////////////////////////
THIS FOLDER CONTAINS THE REPLICATION CODE AND DATA FOR THE PAPER:
Laxminarayan, Ramanan, Julian Reif, and Anup Malani. "Incentives for Reporting Disease Outbreaks." PLOS ONE, 9(3) (2014): e90290.
/////////////////////////////////////

The Stata script "tables_figures.do" produces the main tables and figures in the paper.
The script outputs its results to the /results folder.

The "tables_figures.do" script requires the following Stata modules:
(1) xmltab

The code for that module is included in the /ado folder.

ERRATUM:
Column (2) of Table 2 in the PLOS ONE publication is incorrect. The correct numbers are available in /results/Table2.txt.