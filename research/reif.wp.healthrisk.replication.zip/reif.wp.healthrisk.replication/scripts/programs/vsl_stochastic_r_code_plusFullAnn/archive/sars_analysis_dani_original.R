inputdir <- "C:/Users/jreif/Dropbox/Economics/Research/Insurance and longevity/analysis/scripts/programs/vsl_stochastic_r_code_plusFullAnn"
setwd(inputdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# NPV of wealth age age 50 when not annuitized (estimate comes from deterministic model)
w_0    <- 807604


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age

data_mort <-  read.csv(paste(inputdir,"/sars_cohort_mortality.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/covid_cohort_quality_un.csv",sep=""),header = TRUE)
#data_qual <-  read.csv(paste(inputdir,"/covid_cohort_quality_zeroed.csv",sep=""),header = TRUE) #QUALITY OF LIFE = 1 
data_trans <- read.csv(paste(inputdir,"/sars_cohort_transitions.csv",sep=""),header = TRUE)
data_rates <- matrix(c(rep(0,4080),rep(0,4080),rep(intr,4080)),nrow=4080,ncol=3,byrow=FALSE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("Wealth_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")
source("VFunComplete_routines.R")
source("VSLComplete_routines.R")

# FOR JULIAN: INTRO TO NEW ROUTINES IN COMPLETE CASE 

#(Note that states 61-80 are our post-covid world, so they compare to our "regular" stochastic analysis)
calcVSL(50,61,w_0) #Same VSL as in state 1 before
calcVSI(50,61,80,w_0) #Same for VSI
#New stuff, completely annuitized versions:
calcTheta(50,61,w_0) #calculates marginal utility at time zero (theta) given initial age, state, and wealth
calcVFunComplete(50,61,w_0) #calculates value function at time zero given initial age, state, and wealth
calcVFunComplete(50,61,w_0)/calcTheta(50,61,w_0) - w_0 #gives complete VSL
calcVSLComplete(50,61,w_0) #can also calculate directly
#since individual is fully annuitized, wealth changes when aging/after transtion 
calcWealthAfter(50,61,w_0,60,62) #gives wealth for initial age, state, and wealth -- and age and state now
calcVSLComplete(50,61,w_0) - calcVSLComplete(50,80,calcWealthAfter(50,61,w_0,50,80)) #can be used to calculate VSI as differnce of VSL after updating wealth
calcVSIComplete(50,61,80,w_0) #but can also calculate directly

#FIGURES FOR US

#LIFE EXPECTANCIES
#(grid: horizontal ages 50,60,70,80,80; vertical states 1,7,14,20 through 4 hyper states)
LEs <- matrix(rep(0,80),nrow=16,ncol=5)
for (x in 1:5){
  for (hyp in 1:4){
    LEs[(hyp-1)*4 + 1,x] <- calcLE(50+(x-1)*10,(hyp-1)*20 + 1)
    LEs[(hyp-1)*4 + 2,x] <- calcLE(50+(x-1)*10,(hyp-1)*20 + 7)
    LEs[(hyp-1)*4 + 3,x] <- calcLE(50+(x-1)*10,(hyp-1)*20 + 14)
    LEs[(hyp-1)*4 + 4,x] <- calcLE(50+(x-1)*10,(hyp-1)*20 + 20)
  }
}

#DISCOUNTED QUALITY-ADJUSTED LIFE EXPECTANCIES
#(grid: horizontal ages 50,60,70,80,80; vertical states 1,7,14,20 through 4 hyper states)
QLEs <- matrix(rep(0,80),nrow=16,ncol=5)
for (x in 1:5){
  for (hyp in 1:4){
    QLEs[(hyp-1)*4 + 1,x] <- calcQualAdjLE(50+(x-1)*10,(hyp-1)*20 + 1,intrate = intr)
    QLEs[(hyp-1)*4 + 2,x] <- calcQualAdjLE(50+(x-1)*10,(hyp-1)*20 + 7,intrate = intr)
    QLEs[(hyp-1)*4 + 3,x] <- calcQualAdjLE(50+(x-1)*10,(hyp-1)*20 + 14,intrate = intr)
    QLEs[(hyp-1)*4 + 4,x] <- calcQualAdjLE(50+(x-1)*10,(hyp-1)*20 + 20,intrate = intr)
  }
}

#WEALTH CALIBRATION
w_49plusx <- rep(w_0,51)
for (i in 1:50){
  w_49plusx[1+i] <- calcWealthAfter(50,61,w_0,50+i,61)
}
w_49plusx_2 <- calcPATH(50,rep(1,51),w_0)[3,]
#Alternative:
#set.seed(1)
#w_49plusx_21 <- colMeans(simVSL(500,50,1,w_0,TOSIM=3))[21] 
#w_49plusx_21[21] is 427,665.5
w_49plusx_3 <- calcWpsi(50,1,w_0,psi=1)/(calcWpsi(50,1,w_0)+0.00000000000001)

#VSL FOR 70 YEAR OLDS
#(fully annuitized and non-annuitized, in different hyper states)
VSL_full <- matrix(rep(0,60),nrow=3,ncol=20)
VSL_noan_wcalib1 <- matrix(rep(0,60),nrow=3,ncol=20)
VSL_noan_wcalib2 <- matrix(rep(0,60),nrow=3,ncol=20)
VSL_noan_wcalib3 <- matrix(rep(0,60),nrow=3,ncol=20)

for (health in 1:20){
  for (hyp in 2:4){
    VSL_full[hyp-1,health] <- calcVSLComplete(70,(hyp-1)*20 + health,calcWealthAfter(50,1,w_0,70,(hyp-1)*20 + health))
    VSL_noan_wcalib1[hyp-1,health] <- calcVSL(70,(hyp-1)*20 + health,w_49plusx[21])
    VSL_noan_wcalib2[hyp-1,health] <- calcVSL(70,(hyp-1)*20 + health,w_49plusx_2[21])
    VSL_noan_wcalib3[hyp-1,health] <- calcVSL(70,(hyp-1)*20 + health,w_49plusx_3[(hyp-1)*20 + health,21])
  }
}

#VSIs
#(fully annuituzed and non-annuitized, across ages and health states)
VSI_full <- matrix(rep(0,30),nrow=10,ncol=3)
VSI_noan_wcalib3 <- matrix(rep(0,30),nrow=10,ncol=6)

for (x in 1:5){
    VSI_full[(x-1)*2+1,1] <- calcVSIComplete(50+(x-1)*10,1,21,calcWealthAfter(50,1,w_0,50+(x-1)*10,1))
    VSI_full[(x-1)*2+2,1] <- calcVSIComplete(50+(x-1)*10,20,40,calcWealthAfter(50,1,w_0,50+(x-1)*10,20))                                             
      
    VSI_full[(x-1)*2+1,2] <- calcVSIComplete(50+(x-1)*10,21,41,calcWealthAfter(50,1,w_0,50+(x-1)*10,21))
    VSI_full[(x-1)*2+2,2] <- calcVSIComplete(50+(x-1)*10,40,60,calcWealthAfter(50,1,w_0,50+(x-1)*10,40))    
    
    VSI_full[(x-1)*2+1,3] <- calcVSIComplete(50+(x-1)*10,21,61,calcWealthAfter(50,1,w_0,50+(x-1)*10,21))
    VSI_full[(x-1)*2+2,3] <- calcVSIComplete(50+(x-1)*10,40,80,calcWealthAfter(50,1,w_0,50+(x-1)*10,40))    
    
    VSI_noan_wcalib3[(x-1)*2+1,1] <- calcVSI(50+(x-1)*10,1,21,w_49plusx_3[1,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,1] <- calcVSI(50+(x-1)*10,20,40,w_49plusx_3[20,1+(x-1)*10])
    
    VSI_noan_wcalib3[(x-1)*2+1,2] <- calcVSI(50+(x-1)*10,21,41,w_49plusx_3[21,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,2] <- calcVSI(50+(x-1)*10,40,60,w_49plusx_3[40,1+(x-1)*10])
    
    VSI_noan_wcalib3[(x-1)*2+1,3] <- calcVSI(50+(x-1)*10,21,61,w_49plusx_3[21,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,3] <- calcVSI(50+(x-1)*10,40,80,w_49plusx_3[40,1+(x-1)*10])
    
    VSI_noan_wcalib3[(x-1)*2+1,4] <- calcVSL(50+(x-1)*10,1,w_49plusx_3[1,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,4] <- calcVSL(50+(x-1)*10,20,w_49plusx_3[20,1+(x-1)*10])
    
    VSI_noan_wcalib3[(x-1)*2+1,5] <- calcVSL(50+(x-1)*10,21,w_49plusx_3[21,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,5] <- calcVSL(50+(x-1)*10,40,w_49plusx_3[40,1+(x-1)*10])
    
    VSI_noan_wcalib3[(x-1)*2+1,6] <- calcVSL(50+(x-1)*10,41,w_49plusx_3[21,1+(x-1)*10])
    VSI_noan_wcalib3[(x-1)*2+2,6] <- calcVSL(50+(x-1)*10,60,w_49plusx_3[40,1+(x-1)*10])
    
}

#FIGURES FOR PAPER


#VSL FOR 70 YEAR OLDS
#(fully annuitized and non-annuitized, in different hyper states)
VSL_full_p <- rep(0,60)
VSL_noan_wcalib3_p <- rep(0,60)
LE_for_VSL <- rep(0,60)

for (state in 1:60){
  LE_for_VSL[state] <- calcLE(70,state)
  VSL_full_p[state] <- calcVSLComplete(70,state,calcWealthAfter(50,1,w_0,70,state))
  VSL_noan_wcalib3_p[state] <- calcVSL(70,state,w_49plusx_3[state,21])
}

FIG_VSL <- matrix(c(LE_for_VSL,VSL_full_p,VSL_noan_wcalib3_p),nrow=60,ncol=3)

#WTP FOR 70 YEAR OLDS

WTP_noan_wcalib3 <- matrix(rep(0,200),nrow=20,ncol=10)

for (state in 1:20){
  
  WTP_noan_wcalib3[state,1] <- w_49plusx_3[state,21]
  
  WTP_noan_wcalib3[state,2] <- calcLE(70,0*20 + state)
  WTP_noan_wcalib3[state,3] <- calcLE(70,1*20 + state)
  WTP_noan_wcalib3[state,4] <- calcLE(70,2*20 + state)
  
  WTP_noan_wcalib3[state,5]  <- calcVSI(70,state,20+state,w_49plusx_3[state,21])/(calcQualAdjLE(70,state,intrate = intr)-calcQualAdjLE(70,20+state,intrate = intr))
  WTP_noan_wcalib3[state,6]  <- calcVSI(70,20+state,40+state,w_49plusx_3[20+state,21])/(calcQualAdjLE(70,20+state,intrate = intr)-calcQualAdjLE(70,40+state,intrate = intr))
  WTP_noan_wcalib3[state,7]  <- calcVSI(70,20+state,60+state,w_49plusx_3[20+state,21])/(calcQualAdjLE(70,20+state,intrate = intr)-calcQualAdjLE(70,60+state,intrate = intr))
  
  WTP_noan_wcalib3[state,8]   <- calcVSL(70,state,w_49plusx_3[state,21])/calcQualAdjLE(70,state,intrate = intr)
  WTP_noan_wcalib3[state,9]   <- calcVSL(70,20+state,w_49plusx_3[20+state,21])/calcQualAdjLE(70,20+state,intrate = intr)
  WTP_noan_wcalib3[state,10]  <- calcVSL(70,40+state,w_49plusx_3[40+state,21])/calcQualAdjLE(70,40+state,intrate = intr)
}