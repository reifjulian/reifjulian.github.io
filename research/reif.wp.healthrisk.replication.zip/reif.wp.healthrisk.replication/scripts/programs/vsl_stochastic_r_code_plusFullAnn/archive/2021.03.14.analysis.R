###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  initial_wealth <- as.numeric(c(args[1]))
  projdir <- args[2]
  outputdir <- args[3]
  
  mort_input <- args[4]
  qual_input <- args[5]
  trans_input <- args[6]
  rates_input <- args[7]
  rates_input_alt <- args[8]
  beq_input <- args[9]
  
  gamma <- as.numeric(c(args[10]))
  num_sims <- as.numeric(c(args[11]))

} else {

  # Else, script is being run interactively
  initial_wealth <- 1624508
  projdir <- Sys.getenv("Longevity")
  outputdir <- paste(projdir,"/results/intermediate/stochastic",sep="")
  
  mort_input <- paste0(projdir,"/processed/fem/baseline_cohort_mortality.csv")  
  qual_input  <- paste0(projdir,"/processed/fem/baseline_cohort_quality.csv")
  trans_input <- paste0(projdir,"/processed/fem/baseline_cohort_transitions.csv")
  rates_input <- paste0(projdir,"/processed/fem/baseline_cohort_oopmd_return.csv")
  rates_input_alt <- paste0(projdir,"/processed/fem/baseline_cohort_s14age70_return.csv")
  
  gamma <- 1.25
  num_sims <- 2
}

workdir   = paste(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INITIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth
w_0 <- initial_wealth

#################################################
## BASELINE SCENARIO
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")


#####
# Life expectancies for all ages and states
#####
number_ages <- 99-50+1
LE_qaly <- matrix(0,nrow=n_states*number_ages,ncol=4)
for (i in 1:number_ages) {
for (j in 1:n_states){
  index = (i-1)*(n_states)+j
  LE_qaly[index,1] <- i
  LE_qaly[index,2] <- j
  LE_qaly[index,3] <- calcLE(50+i-1,j)
  LE_qaly[index,4] <- calcQualAdjLE(50+i-1,j,intrate = intr)
}
}
write.csv(LE_qaly, file = paste(outputdir,"/age_state_le_qaly.csv",sep=""))

#####
# VSL simulations
#####
# Syntax: simVSL(NSIMS, age_init, state_init, wealth, type), where type is: 1=consumption, 2=VSL (default), and 3=wealth

set.seed(42)
myVSLs <- simVSL(num_sims,50,1,w_0)

write.csv(t(myVSLs[[1]]), file = paste(outputdir,"/sims_VSL.csv",sep=""))
write.csv(t(myVSLs[[2]]), file = paste(outputdir,"/sims_path.csv",sep=""))
write.csv(t(myVSLs[[3]]), file = paste(outputdir,"/sims_wealth.csv",sep=""))

##
# For the set of people at age 70 in health state 1, calculate all VSI's
##
vsi_age <- 70
vsi_state <- 1

is_age70_state1 <- t(myVSLs[[2]])[vsi_age-50+1,] == vsi_state
paths_age70_state1 <- t(myVSLs[[2]])[,is_age70_state1]

sims_vsi <- matrix(0,n_states, ncol(paths_age70_state1))

for (i in 1:ncol(paths_age70_state1)) {
  
  # Grab path and calculate wealth associated with that path (needed for calcVSI)
  my_path <- paths_age70_state1[,i]
  cons_vsl_wealth  <- calcPATH(50,my_path,w_0)
  
  for (j in 1:n_states) {
    
    my_vsi <- calcVSI(vsi_age,my_path[vsi_age-50+1],j,cons_vsl_wealth[3,vsi_age-50+1])
    sims_vsi[j,i] <- my_vsi
  }
}
write.csv(sims_vsi, file = paste(outputdir,"/sims_vsi_age70.csv",sep=""))

###
# Consumption and VSL for person suffering two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 14 for remaining years
###

# "The first shock reduces her life expectancy by 3.0 years"
# "The second one reduces her life expectancy by 6.8 years"
# "The FEM estimates that life expectancy for this sick patient is 8.5 years at age 70"
#stopifnot( abs(calcLE(60,1)-calcLE(60,6) - 3.037016)<0.0001 )
#stopifnot( abs(calcLE(70,6)-calcLE(70,14) - 6.830474)<0.0001 )
#stopifnot( abs(calcLE(70,14) - 8.505162)<0.0001 )

sickpath    <- c(rep(1,10),rep(6,10),rep(14,(max_age - age + 1)-10-10))

slist <- c("base", "alt")
for (scen in slist) {

	# LOAD DATA
  data_mort <-  read.csv(mort_input,header = TRUE)
  data_qual <-  read.csv(qual_input,header = TRUE)
  data_trans <- read.csv(trans_input,header = TRUE)
  
  if (scen=="base") {
    data_rates <- read.csv(rates_input,header = TRUE)
  }
  else {
    data_rates <- read.csv(rates_input_alt,header = TRUE)  
  }
  
	source("subroutines/VSL_data_init.R")
	source("subroutines/VSL_solution_init.R")

	source("subroutines/VSL_routines.R")
	source("subroutines/LE_routines.R")
	source("subroutines/VFun_routines.R")
	source("subroutines/Path_routines.R")
	source("subroutines/Sim_routines.R")

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0)
	write.csv(t(ConsAndVSLpathSick), file = paste(outputdir,"/c_vsl_w_health_shock",scen,".csv",sep=""))
}


