# This script is intended to be called by Stata, which feeds it the arguments it needs
# If run standalone, the script assumes the project directory has been set by the system variable "Longevity". 
# --- Alternatively, user can run this as a standalone script by manually editing the line "workdir <- Sys.getenv(c("workdir"))"
args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  projdir <- args[1]
  initial_wealth <- as.numeric(c(args[2]))
} else {
  projdir <- Sys.getenv(c("Longevity"))
  initial_wealth <- 862947
}

setwd(paste0(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn"))
inputdir <- paste0(projdir,"/processed/covid")
outputdir = paste0(projdir,"/results/intermediate_files/stochastic")


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# NPV of wealth age age 50 when not annuitized (estimate comes from deterministic model)
w_0    <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age

data_mort <-  read.csv(paste(inputdir,"/covid_mortality.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/covid_quality.csv",sep=""),header = TRUE)
#data_qual <-  read.csv(paste(inputdir,"/covid_cohort_quality_zeroed.csv",sep=""),header = TRUE) #QUALITY OF LIFE = 1 
data_trans <- read.csv(paste(inputdir,"/covid_transitions.csv",sep=""),header = TRUE)
data_rates <- matrix(c(rep(0,4080),rep(0,4080),rep(intr,4080)),nrow=4080,ncol=3,byrow=FALSE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("Wealth_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")
source("VFunComplete_routines.R")
source("VSLComplete_routines.R")

#####
# Descriptive statistics: LE by health state, for different ages
#####
LE_50 <- matrix(0,nrow=20,ncol=3)
LE_70 <- matrix(0,nrow=20,ncol=3)
for (state in 1:20){
  LE_50[state,1] <- calcLE(50,0*20 + state)
  LE_50[state,2] <- calcLE(50,1*20 + state)
  LE_50[state,3] <- calcLE(50,2*20 + state)
  
  LE_70[state,1] <- calcLE(70,0*20 + state)
  LE_70[state,2] <- calcLE(70,1*20 + state)
  LE_70[state,3] <- calcLE(70,2*20 + state)
}
colnames(LE_50) <- c("LE50_1","LE50_2","LE50_3")
colnames(LE_70) <- c("LE70_1","LE70_2","LE70_3")
write.csv(cbind(LE_50,LE_70), file = paste(outputdir,"/LE_summary_covid.csv",sep=""))


####
# Main estimates
####

w_49plusx_3 <- calcWpsi(50,1,w_0,psi=1)/(calcWpsi(50,1,w_0)+0.00000000000001)



#WTP FOR 70 YEAR OLDS

WTP_noan_wcalib3 <- matrix(rep(0,200),nrow=20,ncol=10)

for (state in 1:20){
  
  WTP_noan_wcalib3[state,1] <- w_49plusx_3[state,21]
  
  WTP_noan_wcalib3[state,2] <- calcLE(70,0*20 + state)
  #WTP_noan_wcalib3[state,3] <- calcLE(70,1*20 + state)
  #WTP_noan_wcalib3[state,4] <- calcLE(70,2*20 + state)
  WTP_noan_wcalib3[state,3] <- -1
  WTP_noan_wcalib3[state,4] <- -1    
  
  WTP_noan_wcalib3[state,5]  <- calcVSI(70,state,20+state,w_49plusx_3[state,21])/(calcQualAdjLE(70,state,intrate = intr)-calcQualAdjLE(70,20+state,intrate = intr))
  WTP_noan_wcalib3[state,6]  <- calcVSI(70,20+state,40+state,w_49plusx_3[20+state,21])/(calcQualAdjLE(70,20+state,intrate = intr)-calcQualAdjLE(70,40+state,intrate = intr))
  WTP_noan_wcalib3[state,7]  <- calcVSI(70,20+state,60+state,w_49plusx_3[20+state,21])/(calcQualAdjLE(70,20+state,intrate = intr)-calcQualAdjLE(70,60+state,intrate = intr))
  
  #WTP_noan_wcalib3[state,8]   <- calcVSL(70,state,w_49plusx_3[state,21])/calcQualAdjLE(70,state,intrate = intr)
  #WTP_noan_wcalib3[state,9]   <- calcVSL(70,20+state,w_49plusx_3[20+state,21])/calcQualAdjLE(70,20+state,intrate = intr)
  WTP_noan_wcalib3[state,8]   <- -1
  WTP_noan_wcalib3[state,9]   <- -1
  
  WTP_noan_wcalib3[state,10]  <- calcVSL(70,40+state,w_49plusx_3[40+state,21])/calcQualAdjLE(70,40+state,intrate = intr)
}

colnames(WTP_noan_wcalib3) <- c("wealth", "LE1","LE2","LE3","VSI_1_2","VSI_2_3","VSI_2_4","VSL1","VSL2","VSL3")

write.csv(WTP_noan_wcalib3, file = paste0(outputdir,"/covid_le_vsi_vsl_age70.csv"))