rm (list = ls())

###############################################################################
# SETUP: parse command-line arguments, and install necessary packages
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# If called from command line, store the relevant arguments
print("Args:")
(args <- commandArgs(trailingOnly = TRUE))
if (length(args)) {
	projdir <- c(args[1])

} else {

	# Else, script is being run interactively and user must define variables here. Note that projdir (path to project directory) must be set below.
	projdir <- file.path("C:/Users/mypath")
}

# Install new packages to first element of .libPaths(). If this path is not writeable 
#  (e.g. after a fresh installation of R), install to default user library path
lib <- .libPaths()[1]
if (!dir.create(lib, showWarnings = FALSE)[1]) {
  lib <- Sys.getenv("R_LIBS_USER")
  dir.create(lib, showWarnings = FALSE)
}

# Select repository for downloading new R packages
repos <- "http://cran.us.r-project.org"

# Specify packages to load, installing as needed
packages <- c()
installed <- packages %in% installed.packages()[, "Package"]
invisible(lapply(packages[!installed], install.packages, lib = lib, repos = repos, dependencies=TRUE))
suppressMessages(invisible(lapply(packages, library, character.only=TRUE)))

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/analysis/scripts/auxiliary/vsl_stochastic_r_code",sep="")
inputdir  = paste(projdir,"/analysis/data/proc/fem",sep="")
outputdir = paste(projdir,"/analysis/results/intermediate_files/stochastic",sep="")

setwd(workdir)


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

gammalist <- c(0.7, 2)

for (g in gammalist) {
	
	# Utility function parameters
	ourgamma  <- g
	subslevel <- 5000
	intr   <- 0.03
	intrho <- 0.03

	# Initial age for the FEM data is 50
	age <- 50
	
	# NPV of wealth age age 50 when not annuitized (estimate comes from deterministic model)
	#w_0    <- 807604
	w_0    <- 100000


	# LOAD DATA: baseline scenario, no medical spending
	data_mort <-  read.csv(paste(inputdir,"/baseline_cohort_mortality.csv",sep=""),header = TRUE)
	data_qual <-  read.csv(paste(inputdir,"/baseline_cohort_quality.csv",sep=""),header = TRUE)
	data_trans <- read.csv(paste(inputdir,"/baseline_cohort_transitions.csv",sep=""),header = TRUE)
	data_rates <- read.csv(paste(inputdir,"/baseline_cohort_nospend_return.csv",sep=""),header = TRUE)

	# Set quality of life equal to 1 for this exercise
	data_qual [,3] <- 1

	# INITIALIZING DATA AND OPTIMAL SOLUTIONS
	source("VSL_data_init.R")
	source("VSL_solution_init.R")

	# SOURCING ROUTINES
	source("VSL_routines.R")
	source("LE_routines.R")
	source("VFun_routines.R")
	source("Path_routines.R")
	source("Sim_routines.R")


	###
	# Consumption and VSL for person sufferring two health shocks
	# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 18 for remaining years
	###	
	sickpath    <- c(rep(1,10),rep(6,10),rep(18,(max_age - age + 1)-10-10))

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0)
	write.csv(t(ConsAndVSLpathSick), file = paste(outputdir,"/c_vsl_rise_fall","_",toString(g),".csv",sep=""))


}




