# This script is intended to be called by Stata, which feeds it the arguments it needs
# If run standalone, the script assumes the project directory has been set by the system variable "Longevity". 
# --- Alternatively, user can run this as a standalone script by manually editing the line "workdir <- Sys.getenv(c("workdir"))"
args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  initial_wealth <- as.numeric(c(args[1]))
  projdir <- args[2]
  mort_input <- args[3]
  qual_input <- args[4]
  trans_input <- args[5]
  rates_input <- args[6]
  output_file <- args[7]
  gamma <- as.numeric(c(args[8]))
  
} else {
  projdir <- Sys.getenv(c("Longevity"))
  initial_wealth <- 862947
}

setwd(paste0(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn"))
outputdir = paste0(projdir,"/results/intermediate_files/stochastic")


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# NPV of wealth age age 50 when not annuitized (estimate comes from deterministic model)
w_0    <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("Wealth_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")
source("VFunComplete_routines.R")
source("VSLComplete_routines.R")


####
# Main estimates
####

# 80 X 51 matrix --> health state X age
w_49plusx_3 <- calcWpsi(50,1,w_0,psi=1)/(calcWpsi(50,1,w_0)+0.00000000000001)



ages <- seq(from=55, to=85, by=5)

WTP_noan_wcalib3 <- matrix(0,nrow=20*length(ages),ncol=12)

cnt = 0
for (age in ages) {
for (state in 1:20){
  
  if(state!=7) {next}
  
  # Wealth levels: pre-pandemic (hyper state 1), outbreak (hyper state 2), infected (hyper state 3)
  wealth_pre <- w_49plusx_3[state   ,age-50+1]
  wealth_out <- w_49plusx_3[20+state,age-50+1]
  wealth_inf <- w_49plusx_3[40+state,age-50+1]
  
  WTP_noan_wcalib3[state+cnt*20,1] <- wealth_pre
  WTP_noan_wcalib3[state+cnt*20,2] <- wealth_out
  WTP_noan_wcalib3[state+cnt*20,3] <- wealth_inf
  
  # Life expectancy (pre-pandemic, outbreak, infected)
  WTP_noan_wcalib3[state+cnt*20,4] <- calcLE(age,0*20 + state)
  WTP_noan_wcalib3[state+cnt*20,5] <- calcLE(age,1*20 + state)
  WTP_noan_wcalib3[state+cnt*20,6] <- calcLE(age,2*20 + state)
  
  # Pandemic prevention, mitigation, vaccine
  WTP_noan_wcalib3[state+cnt*20,7]  <- calcVSI(age,state,20+state,wealth_pre)/(calcQualAdjLE(age,state,intrate = intr)-calcQualAdjLE(age,20+state,intrate = intr))
  WTP_noan_wcalib3[state+cnt*20,8]  <- calcVSI(age,20+state,40+state,wealth_pre)/(calcQualAdjLE(age,20+state,intrate = intr)-calcQualAdjLE(age,40+state,intrate = intr))
  WTP_noan_wcalib3[state+cnt*20,9]  <- calcVSI(age,20+state,60+state,wealth_pre)/(calcQualAdjLE(age,20+state,intrate = intr)-calcQualAdjLE(age,60+state,intrate = intr))

  # VSL (treatment)
  WTP_noan_wcalib3[state+cnt*20,10]  <- calcVSL(age,40+state,wealth_pre)/calcQualAdjLE(age,40+state,intrate = intr)
  
  WTP_noan_wcalib3[state+cnt*20,11]  <- age
  WTP_noan_wcalib3[state+cnt*20,12]  <- state
}
cnt = cnt+1
}

colnames(WTP_noan_wcalib3) <- c("wealth_pre", "wealth_out", "wealth_inf", "LE1","LE2","LE3","VSI_1_2","VSI_2_3","VSI_2_4","VSL","age","health_state")

write.csv(WTP_noan_wcalib3, file = output_file)