rm (list = ls())

###############################################################################
# Parse command-line arguments
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# Parse arguments
args <- commandArgs(trailingOnly = TRUE)
if (length(args)) {
  projdir <- c(args[1])
} else {

  projdir <- file.path("C:/Users/mypath")
}

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/analysis/scripts/auxiliary/vsl_stochastic_r_code",sep="")
inputdir  = paste(projdir,"/analysis/data/proc/fem",sep="")
outputdir = paste(projdir,"/analysis/data/proc/fem/onestate",sep="")

setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- 2.0
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Baseline data (20 health states)
data_mort <-  read.csv(paste(inputdir,"/baseline_cohort_mortality.csv",sep=""),header = TRUE)
data_qual <-  read.csv(paste(inputdir,"/baseline_cohort_quality.csv",sep=""),header = TRUE)
data_trans <- read.csv(paste(inputdir,"/baseline_cohort_transitions.csv",sep=""),header = TRUE)
data_rates <- read.csv(paste(inputdir,"/baseline_cohort_nospend_return.csv",sep=""),header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")


#################################################
## Collapse FEM data into a single health state
#################################################


wzeros <- calcWzeros(50,1)

data_mort_one <- rep(0,51)
data_qual_one <- rep(0,51)
data_rates_one <- rep(0,51)

age <- rep(0,51)
health_state <- rep(1,51)

for (i in 1:51){
  for (j in 1:20){
    data_mort_one[i] <- data_mort_one[i] + mortality[j,i] * wzeros[j,i]
    data_qual_one[i] <- data_qual_one[i] + quality[j,i] * wzeros[j,i]
  }
  data_mort_one[i] <- data_mort_one[i]/sum(wzeros[,i])
  data_qual_one[i] <- data_qual_one[i]/sum(wzeros[,i])
  
  # Rates are constant across states
  data_rates_one[i] <- data_rates[i,3]
  
  # Ages
  age[i] <- 49+i
  
}

# Transition probability is a constant 1, and so is health state
data_trans_one <- rep(1,51)

data_mort_one <- cbind(age,health_state,data_mort_one)
data_qual_one <- cbind(age,health_state,data_qual_one)
data_rates_one <- cbind(age,health_state,data_rates_one)
data_trans_one <- cbind(age,health_state,data_trans_one)

write.csv(data_mort_one,paste(outputdir,"/baseline_cohort_mortality_one_state.csv",sep=""),row.names=FALSE)
write.csv(data_qual_one,paste(outputdir,"/baseline_cohort_quality_one_state.csv",sep=""),row.names=FALSE)
write.csv(data_trans_one,paste(outputdir,"/transitions_one_state.csv",sep=""),row.names=FALSE)
write.csv(data_rates_one,paste(outputdir,"/returns_one_state.csv",sep=""),row.names=FALSE)


