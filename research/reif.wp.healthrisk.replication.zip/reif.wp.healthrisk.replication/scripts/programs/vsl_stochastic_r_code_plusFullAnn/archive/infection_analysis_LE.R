# This script is intended to be called by Stata, which feeds it the arguments it needs
# If run standalone, the script assumes the project directory has been set by the system variable "Longevity". 
# --- Alternatively, user can run this as a standalone script by manually editing the line "workdir <- Sys.getenv(c("workdir"))"
args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  initial_wealth <- as.numeric(c(args[1]))
  projdir <- args[2]
  mort_input <- args[3]
  qual_input <- args[4]
  trans_input <- args[5]
  rates_input <- args[6]
  output_file <- args[7]
  gamma <- as.numeric(c(args[8]))
  
} else {
  projdir <- Sys.getenv(c("Longevity"))
  initial_wealth <- 862947
}

setwd(paste0(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn"))
outputdir = paste0(projdir,"/results/intermediate_files/stochastic")


#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# NPV of wealth age age 50 when not annuitized (estimate comes from deterministic model)
w_0    <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("Wealth_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")
source("VFunComplete_routines.R")
source("VSLComplete_routines.R")

#####
# Descriptive statistics: LE by health state, for different ages
#####
ages <- c(50,70)

LE <- matrix(0,nrow=20*length(ages),ncol=5)

cnt <- 1
for (age in ages) {
for (state in 1:20) {

  LE[cnt,1] <- age
  LE[cnt,2] <- state
  LE[cnt,3] <- calcLE(age,0*20 + state)
  LE[cnt,4] <- calcLE(age,1*20 + state)
  LE[cnt,5] <- calcLE(age,2*20 + state)

  cnt <- cnt+1
}
}
colnames(LE) <- c("age", "state", "LE_hyper1","LE_hyper2","LE_hyper3")
write.csv(LE, file = paste(outputdir,"/LE_summary_infection.csv",sep=""))

