calcVSLComplete <- function(init_age,init_state,wealth){
  VSL <- 0
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intr   <- 0.03
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  hlp <- subslevel^(1-ourgamma)*calcQualAdjLE(init_age,init_state, intrate = intrho)/calcTheta(init_age,init_state,wealth)
  hlp <- hlp - ourgamma * wealth
  hlp <- hlp / (ourgamma-1)
  return(hlp)
  
}

calcVSIComplete <- function(init_age,fromstate,tostate,wealth){
 
  hlp <- subslevel^(1-ourgamma)/calcTheta(init_age,fromstate,wealth)
  hlp <- hlp * (calcQualAdjLE(init_age,fromstate, intrate = intrho)-calcQualAdjLE(init_age,tostate, intrate = intrho))
  hlp <- hlp - ourgamma * (wealth-calcWealthAfter(init_age,fromstate,wealth,init_age,tostate))
  hlp <- hlp / (ourgamma-1)
  return(hlp)
}