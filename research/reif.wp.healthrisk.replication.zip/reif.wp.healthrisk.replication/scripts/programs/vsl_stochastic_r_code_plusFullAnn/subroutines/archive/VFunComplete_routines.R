calcVFunComplete <- function(init_age,init_state,wealth){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myret <- wealth * calcTheta(init_age,init_state,wealth) - subslevel^(1-ourgamma)*calcQualAdjLE(init_age,init_state, intrate = intrho)
  myret <- myret / (1-ourgamma)
  return(myret)
}

calcTheta <- function(init_age,init_state,wealth){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myret <- calcQualAdjPowLE(init_age,init_state,intrate = intr + (intrho-intr)/ourgamma, qualpow = 1/ourgamma)
  myret <- (myret/wealth)^ourgamma
  return(myret)
}

calcWealthAfter <- function(init_age,init_state,wealth,new_age,new_state){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((new_age < min_age) || (new_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((new_state < min_state) || (new_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myret <- calcQualAdjPowLE(new_age,new_state,intrate = intr + (intrho-intr)/ourgamma, qualpow = 1/ourgamma)
  myret <- myret / (calcTheta(init_age,init_state,wealth)^(1/ourgamma))
  
  return(myret)
}
