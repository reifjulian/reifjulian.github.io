rm (list = ls())

###############################################################################
# SETUP: parse command-line arguments, and load necessary packages
###############################################################################

# Report R version and platform information
paste(R.Version()$version.string,R.Version()$platform)

# If called from command line, store the relevant arguments
print("Args:")
(args <- commandArgs(trailingOnly = TRUE))
if (length(args)) {
  initial_wealth <- as.numeric(c(args[1]))
  projdir <- args[2]
  
  mort_input <- args[3]
  qual_input <- args[4]
  trans_input <- args[5]
  rates_input <- args[6]
  beq_input <- args[7]
  
  gamma <- as.numeric(c(args[8]))
  num_sims <- as.numeric(c(args[9]))

} else {

  # Else, script is being run interactively and user must define variables here. Note that projdir (path to project directory) must be set below.
  projdir <- Sys.getenv("Longevity")
  initial_wealth <- 862947
  outputdir <- paste(projdir,"/results/intermediate/stochastic_bequests",sep="")
  
  mort_input <- paste0(projdir,"/processed/fem/baseline_cohort_mortality.csv")
  qual_input  <- paste0(projdir,"/processed/fem/baseline_cohort_quality.csv")
  trans_input <- paste0(projdir,"/processed/fem/baseline_cohort_transitions.csv")
  rates_input <- paste0(projdir,"/processed/fem/baseline_cohort_oopmd_return.csv")
  beq_input   <- paste0(projdir,"/processed/fem/baseline_cohort_bequest.csv")

  gamma <- 1.25
  num_sims <-2
}

#################################################
## DEFINE DIRECTORY STRUCTURE
#################################################

workdir   = paste(projdir,"/scripts/programs/vsl_stochastic_r_code_bequests",sep="")
inputdir  = paste(projdir,"/processed/fem",sep="")

setwd(workdir)


#################################################
## PARAMETERS AND INITIALIZATIONS
#################################################

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth
w_0 <- initial_wealth

#################################################
## BASELINE SCENARIO
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)
data_beq <-   read.csv(beq_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("VSL_data_init.R")
source("VSL_solution_init.R")

# SOURCING ROUTINES
source("VSL_routines.R")
source("LE_routines.R")
source("VFun_routines.R")
source("Path_routines.R")
source("Sim_routines.R")

#####
# VSL simulations
#####
# Syntax: simVSL(NSIMS, age_init, state_init, wealth, type), where type is: 1=consumption, 2=VSL (default), and 3=wealth
#  -- update: simVSL now also returns path and wealth
print("Running VSL simulations...")
set.seed(42)
myVSLs <- simVSL(num_sims,50,1,w_0)
write.csv(t(myVSLs[[1]]), file = paste(outputdir,"/sims_VSL.csv",sep=""))
write.csv(t(myVSLs[[2]]), file = paste(outputdir,"/sims_path.csv",sep=""))
write.csv(t(myVSLs[[3]]), file = paste(outputdir,"/sims_wealth.csv",sep=""))

##
# For the set of people at age 70 in health state 1, calculate all VSI's
##
vsi_age <- 70
vsi_state <- 1

is_age70_state1 <- t(myVSLs[[2]])[vsi_age-50+1,] == vsi_state
paths_age70_state1 <- t(myVSLs[[2]])[,is_age70_state1]

sims_vsi <- matrix(0,n_states, ncol(paths_age70_state1))

for (i in 1:ncol(paths_age70_state1)) {
  
  # Grab path and calculate wealth associated with that path (needed for calcVSI)
  my_path <- paths_age70_state1[,i]
  cons_vsl_wealth  <- calcPATH(50,my_path,w_0)
  
  for (j in 1:n_states) {
    
    my_vsi <- calcVSI(vsi_age,my_path[vsi_age-50+1],j,cons_vsl_wealth[3,vsi_age-50+1])
    
    sims_vsi[j,i] <- my_vsi
  }
}
write.csv(sims_vsi, file = paste(outputdir,"/sims_vsi_age70.csv",sep=""))

#####
# VSL vs VSI at age 50
#####

age <- 50
VSL_VSI_results <- matrix(0,nrow=n_states,ncol=6)

for (i in 1:n_states){
  VSL_VSI_results[i,1] <- age
  VSL_VSI_results[i,2] <- i
  VSL_VSI_results[i,3] <- calcLE(age,i)
  VSL_VSI_results[i,4] <- calcQualAdjLE(age,i,intrate = intr)
  VSL_VSI_results[i,5] <- calcVSL(age,i,w_0)
  VSL_VSI_results[i,6] <- calcVSI(age,1,i,w_0)
}
colnames(VSL_VSI_results) <- c("age","state", "life_expectancy", "QALY_life_expectancy", "VSL", "VSI")
write.csv(VSL_VSI_results, file = paste(outputdir,"/vsl_vsi_age50.csv",sep=""))



###
# Consumption and VSL for person suffering two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 14 for remaining years
###

# "The first shock reduces her life expectancy by 3.0 years"
# "The second one reduces her life expectancy by 6.8 years"
# "The FEM estimates that life expectancy for this sick patient is 8.5 years at age 70"
#stopifnot( abs(calcLE(60,1)-calcLE(60,6) - 3.037016)<0.0001 )
#stopifnot( abs(calcLE(70,6)-calcLE(70,14) - 6.830474)<0.0001 )
#stopifnot( abs(calcLE(70,14) - 8.505162)<0.0001 )

#
healthypath <- c(rep(1,10),rep(6,(max_age - age + 1)-10))
sickpath    <- c(rep(1,10),rep(6,10),rep(14,(max_age - age + 1)-10-10))

#ConsAndVSLpathSick  <- calcPATH(50,sickpath,w_0)
#plot(ConsAndVSLpathSick[2,1:50],type = "l")


slist <- c("_oopmd", "_s14age70")
for (scen in slist) {

	# LOAD DATA
	data_mort <-  read.csv(mort_input,header = TRUE)
	data_qual <-  read.csv(qual_input,header = TRUE)
	data_trans <- read.csv(trans_input,header = TRUE)
	data_rates <- read.csv(paste(inputdir,"/baseline_cohort",scen,"_return.csv",sep=""),header = TRUE)
	data_beq <-   read.csv(beq_input,header = TRUE)

	source("VSL_data_init.R")
	source("VSL_solution_init.R")

	source("VSL_routines.R")
	source("LE_routines.R")
	source("VFun_routines.R")
	source("Path_routines.R")
	source("Sim_routines.R")

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0)
	write.csv(t(ConsAndVSLpathSick), file = paste(outputdir,"/c_vsl_w_health_shock",scen,".csv",sep=""))

	VSLsick = ConsAndVSLpathSick[2,]

	# Calculate VSI (of preventing state 20) for a person who remains in state 2
	# Note: ConsAndVSLpathHealthy and VSLvec below should produce same results
	
	ConsAndVSLpathHealthy  <- calcPATH(50,healthypath,w_0)

	VSLsick <- rep(0,max_age-age+1)
	VSI     <- rep(0,max_age-age+1)

	StateHealthy <- rep(0,max_age-age+1)
	StateSick    <- rep(0,max_age-age+1)
	QALYsick       <- rep(0,max_age-age+1)
	QALYhealthy    <- rep(0,max_age-age+1)
	for (a in age:max_age){
		
		i = a-age+1
		VSI[i] <- calcVSI(a,healthypath[i],20,ConsAndVSLpathHealthy[3,i])

		StateHealthy[i] <- healthypath[i]
		StateSick[i]    <- sickpath[i]
		QALYhealthy[i] <- calcQualAdjLE(a,healthypath[i],intrate = intr)
		QALYsick[i]       <- calcQualAdjLE(a,sickpath[i],intrate = intr)

		# For purposes of comparison
		VSLsick[i] <- calcVSL(a,sickpath[i],ConsAndVSLpathSick[3,i])
	}
	write.csv(t(rbind(StateHealthy,StateSick,QALYhealthy,QALYsick,VSLsick,VSI)), file = paste(outputdir,"/vsl_vsi_healthshock",scen,".csv",sep=""))
}


