###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  projdir <- args[1]
  
  mort_input <- args[2]
  qual_input <- args[3]
  trans_input <- args[4]
  rates_input <- args[5]
  
  sims_inputfile <- args[6]
  sims_outputfile <- args[7]
  
  gamma <- as.numeric(c(args[8]))

} else {

  # Else, script is being run interactively
  projdir <- Sys.getenv("Longevity")
  
  wealth_nsims_input <- paste0(projdir,"/processed/fem/wealth_nsims.csv")
  
  mort_input <- paste0(projdir,"/processed/fem/baseline_cohort_mortality.csv")  
  qual_input  <- paste0(projdir,"/processed/fem/baseline_cohort_quality.csv")
  trans_input <- paste0(projdir,"/processed/fem/baseline_cohort_transitions.csv")
  rates_input <- paste0(projdir,"/processed/fem/baseline_cohort_oopmd_return.csv")
  
  sims_inputfile <- paste0(projdir,"/results/intermediate/base_1.25/simulations_processed.csv")
  sims_outputfile <- paste0(projdir,"/results/intermediate/base_1.25/simulations_processed_cf.csv")

  gamma <- 1.25
}

workdir   = paste(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INITIALIZATIONS
#################################################

set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50


#################################################
## BASELINE SCENARIO
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")

###
# Calculate counterfactual VSL in the event that a state transition had not occurred
###
our_file <- read.csv(sims_inputfile,header = TRUE)
our_file$VSL_prev <- rep(0,nrow(our_file))
for (i in 1:nrow(our_file)) {
  our_file$VSL_prev[i] = calcVSL(our_file$age[i],our_file$state_prev[i],our_file$wealth[i])
}

write.csv(our_file,sims_outputfile)

## EOF