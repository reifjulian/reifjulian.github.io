###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  target_vsl <- as.numeric(args[1])
  projdir <- args[2]
  output_file <- args[3]
  
  mort_input <- args[4]
  qual_input <- args[5]
  trans_input <- args[6]
  rates_input <- args[7]
  
  population_age50_input <- args[8]
  wealth_age50_input <- args[9]
  
  gamma <- as.numeric(c(args[10]))
} else {
  target_vsl <- 6000000
  projdir <- Sys.getenv(c("Longevity"))
  output_file <- paste(projdir,"/results/intermediate/output.csv",sep="")
  
  mort_input <-  paste(projdir,"/processed/baseline_cohort_mortality.csv",sep="")
  qual_input <-  paste(projdir,"/processed/baseline_cohort_quality.csv",sep="")
  trans_input <- paste(projdir,"/processed/baseline_cohort_transitions.csv",sep="")
  rates_input <- paste(projdir,"/processed/baseline_cohort_oopmd_return.csv",sep="")
  
  population_age50_input <- paste(projdir,"/processed/population_age50.csv",sep="")
  wealth_age50_input <- paste(projdir,"/processed/age50_wealth.csv",sep="")
  
  gamma <- 1.25
}

# Load packages
library(rootSolve)

workdir <- paste(projdir,"/scripts/programs/model-baseline",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################
set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

data_age50_health <- read.csv(population_age50_input,header = TRUE)
data_age50_wealth <- read.csv(wealth_age50_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")

# Weights for the 20 different states
weights <- data_age50_health[,"pct"]/100

# Initial wealth values for the 20 states
wealth_0 <- data_age50_wealth[,"wealth"]*1000

# Initial multiplier on wealth
multiplier_0 <- 1


# Solve for wealth multiplier that yields average target VSL
fun <- function (x) {
  
  sum <- 0 
  for(i in 1:20) {
    sum <- sum + calcVSL(50,i,wealth_0[i]*x)*weights[i]
  }
  return(sum - target_vsl)
}
target_multiplier <- uniroot(fun, c(multiplier_0, 200))$root

sum <- 0 
wealth_solution <- rep(-1,20)
vsl_solution <- rep(-1,20)
for(i in 1:20) {
  wealth_solution[i] <- wealth_0[i]*target_multiplier
  vsl_solution[i] <- calcVSL(50,i,wealth_solution[i])
  
  print(calcVSL(50,i,wealth_solution[i]))
  sum <- sum + calcVSL(50,i,wealth_0[i]*target_multiplier)*weights[i]
}
print(paste("When multiplier is set equal to ",round(target_multiplier,3)," then average VSL at age 50 is ",round(sum),sep=""))


write.csv(cbind(wealth_solution,vsl_solution), file = output_file)


