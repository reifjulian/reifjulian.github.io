calcLE <- function(init_age,init_state, intrate = 0, RETPROBS = FALSE){
  
  LE <- 0
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  if(init_age == n_ages + min_age - 1){
    return(0.5)
  }
  
  
  w_zero         <- matrix(0, nrow = n_states, ncol = n_ages - (init_age-min_age))
  w_zero[init_state + (min_state - 1), 1]       <- 1
  
  for (i in 2:(n_ages - (init_age-min_age))){
    for (j in 1:n_states){
      for (k in 1:n_states){
        w_zero[j,i]      <- w_zero[j,i] + w_zero[k,i-1] * (1 - mortality[k,(init_age-min_age) + i - 1]) * transition[k,(init_age-min_age) + i - 1,j]
      }
    }
  }
  
  barprobs <- rep(0,(n_ages - (init_age-min_age)))

  for (i in 1:(n_ages - (init_age-min_age))){
   barprobs[i] <- exp(-intrate  * (i - 1)) * sum(w_zero[,i])
  }
  if (RETPROBS){
    return(barprobs)
  } else{
    return(sum(barprobs[1:(n_ages - (init_age-min_age))]))
  }
}

calcQualAdjLE <- function(init_age,init_state, intrate = 0){
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  if (init_age == n_ages + min_age -1){
    return(quality[init_state,n_ages] + exp(-intrate)*bequest[init_state,n_ages])
  }
  
  w_zero         <- matrix(0, nrow = n_states, ncol = n_ages - (init_age-min_age))
  w_zero[init_state + (min_state - 1), 1]       <- 1
  
  for (i in 2:(n_ages - (init_age-min_age))){
    for (j in 1:n_states){
      for (k in 1:n_states){
        w_zero[j,i]      <- w_zero[j,i] + w_zero[k,i-1] * (1 - mortality[k,(init_age-min_age) + i - 1]) * transition[k,(init_age-min_age) + i - 1,j]
      }
    }
  }
  
  barprobs <- rep(0,(n_ages - (init_age-min_age)))
  
  barprobs[1] <- sum(w_zero[,1]*(quality[,(init_age-min_age) + 1]))
  
  for (i in 2:(n_ages - (init_age-min_age))){
    barprobs[i] <- exp(-intrate  * (i - 1)) * sum(w_zero[,i]*(quality[,(init_age-min_age) + i]))
  }
  return(sum(barprobs[1:(n_ages - (init_age-min_age))]))
}

calcQualAndBeqAdjLE <- function(init_age,init_state, intrate = 0){
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  if (init_age == n_ages + min_age -1){
    #OLD: return(quality[init_state,n_ages] + exp(-intrate)*bequest[init_state,n_ages])
    return(quality[init_state,n_ages] + bequest[init_state,n_ages])
  }
  
  w_zero         <- matrix(0, nrow = n_states, ncol = n_ages - (init_age-min_age))
  w_zero[init_state + (min_state - 1), 1]       <- 1
  
  for (i in 2:(n_ages - (init_age-min_age))){
    for (j in 1:n_states){
      for (k in 1:n_states){
        w_zero[j,i]      <- w_zero[j,i] + w_zero[k,i-1] * (1 - mortality[k,(init_age-min_age) + i - 1]) * transition[k,(init_age-min_age) + i - 1,j]
      }
    }
  }
  
  barprobs <- rep(0,(n_ages - (init_age-min_age)))
  
  barprobs[1] <- sum(w_zero[,1]*(quality[,(init_age-min_age) + 1]+bequest[,(init_age-min_age) + 1]))
  
  for (i in 2:(n_ages - (init_age-min_age))){
    barprobs[i] <- exp(-intrate  * (i - 1)) * sum(w_zero[,i]*(quality[,(init_age-min_age) + i] + bequest[,(init_age-min_age) + i]))
    barprobs[i] <- barprobs[i] - exp(-intrate  * (i - 1)) * sum(w_zero[,i]) * exp(intrate) * bequest[1,(init_age-min_age) + i - 1] #Careful, revisit with state-contingent bequest
  }
  return(sum(barprobs[1:(n_ages - (init_age-min_age))]))
}



