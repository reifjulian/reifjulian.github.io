calcPATH <- function(init_age,state_path,wealth_zero){

  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if (length(state_path) < (max_age - init_age)){
    print("Not enough state information")
    return(-1)
  }
  
  mypath <- matrix(0, nrow = 3, ncol = (n_ages - (init_age-min_age)))
  
  wealth <- wealth_zero
  
  for (i in 1:(n_ages - (init_age-min_age))){
    mypath[3,i] <- wealth
    mypath[2,i] <- calcVSL(init_age - 1 + i,state_path[i],wealth)
    mypath[1,i] <- wealth * optimalc[state_path[i],(init_age-min_age) + i]
    wealth      <- (wealth - mypath[1,i]) * exp(rates[state_path[i],(init_age-min_age) + i,state_path[i+1]])
  }
  
  return(mypath)
}