simPATHS <- function(numpaths,init_age,init_state){
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  mypaths <- matrix(0, nrow = numpaths, ncol = n_ages - (init_age-min_age))
  for (n in 1:numpaths){
    mypaths[n,1] <- init_state
    for(i in 2:(n_ages - (init_age-min_age))){
      mypaths[n,i] <- sample(n_states,1,replace=TRUE,prob=transition[mypaths[n,i-1],(init_age-min_age) + i,])
    }
  }
  
  return(mypaths)
  
}

simVSL <- function(numpaths,init_age,init_state,wealth_zero,TOSIM = 2){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  myVSLpaths <- matrix(0, nrow = numpaths, ncol = n_ages - (init_age-min_age))
  myWEALTHpaths <- matrix(0, nrow = numpaths, ncol = n_ages - (init_age-min_age))
  mySIMpaths <- simPATHS(numpaths,init_age,init_state)
  
  for (i in 1:numpaths){
    hlp                <- calcPATH(init_age,mySIMpaths[i,],wealth_zero)
    myVSLpaths[i,]     <- hlp[TOSIM,]
    myWEALTHpaths[i,]  <- hlp[3,]
  }
  return(list(myVSLpaths,mySIMpaths,myWEALTHpaths))
  
}