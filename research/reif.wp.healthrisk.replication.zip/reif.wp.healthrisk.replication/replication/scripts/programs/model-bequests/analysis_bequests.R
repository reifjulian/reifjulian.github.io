###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  wealth_nsims_input <- args[1]
  projdir <- args[2]
  outputdir <- args[3]
  
  mort_input <- args[4]
  qual_input <- args[5]
  trans_input <- args[6]
  rates_input <- args[7]
  rates_input_alt <- args[8]
  beq_input <- args[9]
  
  gamma      <- as.numeric(c(args[10]))
  w_0_state1 <- as.numeric(c(args[11]))

} else {

  # Else, script is being run interactively
  projdir <- Sys.getenv("Longevity")
  outputdir <- paste(projdir,"/results/intermediate",sep="")
  
  wealth_nsims_input <- paste0(projdir,"/processed/wealth_nsims.csv") 
  mort_input <- paste0(projdir,"/processed/baseline_cohort_mortality.csv")  
  qual_input  <- paste0(projdir,"/processed/baseline_cohort_quality.csv")
  trans_input <- paste0(projdir,"/processed/baseline_cohort_transitions.csv")
  rates_input <- paste0(projdir,"/processed/baseline_cohort_oopmd_return.csv")
  rates_input_alt <- paste0(projdir,"/processed/baseline_cohort_s14age70_return.csv")
  beq_input   <- paste0(projdir,"/processed/baseline_cohort_bequest.csv")
  
  gamma <- 1.25
  w_0_state1   <- 1619039.785
}

workdir   = paste(projdir,"/scripts/programs/model-bequests",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INITIALIZATIONS
#################################################
set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50


#################################################
## BASELINE SCENARIO
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)
data_beq <-   read.csv(beq_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")

#####
# Life expectancies for all ages and states
#####
number_ages <- 99-50+1
LE_qaly <- matrix(0,nrow=n_states*number_ages,ncol=4)
for (i in 1:number_ages) {
for (j in 1:n_states){
  index = (i-1)*(n_states)+j
  LE_qaly[index,1] <- i
  LE_qaly[index,2] <- j
  LE_qaly[index,3] <- calcLE(50+i-1,j)
  LE_qaly[index,4] <- calcQualAdjLE(50+i-1,j,intrate = intr)
}
}
write.csv(LE_qaly, file = paste(outputdir,"/age_state_le_qaly.csv",sep=""))

#####
# VSL simulations
#####
# Syntax: simVSL(NSIMS, age_init, state_init, wealth, type), where type is: 1=consumption, 2=VSL (default), and 3=wealth

myVSLs <- NULL
myPaths <- NULL
myWealths <- NULL

data_wealth_nsims <-  read.csv(wealth_nsims_input,header = TRUE)

for (myState in 1:n_states) {

  myWealth <- data_wealth_nsims[myState,"wealth"]
  num_sims <- data_wealth_nsims[myState,"nsims"]

  myResults <- simVSL(num_sims,50,myState,myWealth)

  myVSLs   <- rbind(myVSLs,myResults[[1]])
  myPaths  <- rbind(myPaths,myResults[[2]])
  myWealths <- rbind(myWealths,myResults[[3]])

  ##
  # For the set of people at age 70 and still in health state 1, calculate all VSI's
  ##
  if(myState==1) {
    vsi_age <- 70
    vsi_state <- 1

    is_age70_state1 <- t(myResults[[2]])[vsi_age-50+1,] == vsi_state
    paths_age70_state1 <- t(myResults[[2]])[,is_age70_state1]

    sims_vsi <- matrix(0,n_states, ncol(paths_age70_state1))

    for (i in 1:ncol(paths_age70_state1)) {

      # Grab path and calculate wealth associated with that path (needed for calcVSI)
      my_path <- paths_age70_state1[,i]
      cons_vsl_wealth  <- calcPATH(50,my_path,data_wealth_nsims[myState,"wealth"])

      for (j in 1:n_states) {

        my_vsi <- calcVSI(vsi_age,my_path[vsi_age-50+1],j,cons_vsl_wealth[3,vsi_age-50+1])
        sims_vsi[j,i] <- my_vsi
      }
    }
    write.csv(sims_vsi, file = paste(outputdir,"/sims_vsi_age70.csv",sep=""))
  }
}
write.csv(t(myVSLs), file = paste(outputdir,"/sims_VSL_allstates.csv",sep=""))
write.csv(t(myPaths), file = paste(outputdir,"/sims_path_allstates.csv",sep=""))
write.csv(t(myWealths), file = paste(outputdir,"/sims_wealth_allstates.csv",sep=""))

###
# Consumption and VSL for person suffering two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 14 for remaining years
###

sickpath    <- c(rep(1,10),rep(6,10),rep(14,(max_age - age + 1)-10-10))

slist <- c("base")
for (scen in slist) {

	# LOAD DATA
  data_mort <-  read.csv(mort_input,header = TRUE)
  data_qual <-  read.csv(qual_input,header = TRUE)
  data_trans <- read.csv(trans_input,header = TRUE)
  data_rates <- read.csv(rates_input,header = TRUE)

  data_beq <-   read.csv(beq_input,header = TRUE)
  
	source("subroutines/VSL_data_init.R")
	source("subroutines/VSL_solution_init.R")

	source("subroutines/VSL_routines.R")
	source("subroutines/LE_routines.R")
	source("subroutines/VFun_routines.R")
	source("subroutines/Path_routines.R")
	source("subroutines/Sim_routines.R")

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0_state1)
	write.csv(t(ConsAndVSLpathSick), file = paste(outputdir,"/c_vsl_w_health_shock",scen,".csv",sep=""))
}