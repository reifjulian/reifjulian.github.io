﻿with_inflation: projects healthcare costs to increase and mortality to decrease in the future

no_inflation_or_mort_decline: zero GDP growth, zero Medical CPI growth, and no all-cause mortality reduction adjustment