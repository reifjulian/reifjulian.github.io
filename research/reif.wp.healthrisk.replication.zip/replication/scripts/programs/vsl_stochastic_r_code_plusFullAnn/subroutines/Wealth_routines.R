calcWpsi <- function(init_age,init_state,wealth,psi = 0){
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intr   <- 0.03
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  wpsi  <- matrix(0, nrow = n_states, ncol = n_ages - (init_age-min_age))
  wpsi[init_state + (min_state - 1), 1]       <- wealth^(psi)
  
  for (i in 2:(n_ages - (init_age-min_age))){
    for (j in 1:n_states){
      for (k in 1:n_states){
        wpsi[j,i]    <- wpsi[j,i] + wpsi[k,i-1] * (1 - optimalc[k,(init_age-min_age) + i - 1])^(psi) * (1 - mortality[k,(init_age-min_age) + i - 1]) * transition[k,(init_age-min_age) + i - 1,j]
      }
      wpsi[j,i] <- wpsi[j,i] * exp(intr * psi)
    }
  }
  return(wpsi)
}