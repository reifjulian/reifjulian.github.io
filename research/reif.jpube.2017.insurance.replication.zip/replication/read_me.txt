/////////////////////////////////////
THIS FOLDER CONTAINS THE REPLICATION CODE AND DATA FOR THE PAPER:
Lakdawalla, Darius, Anup Malani, and Julian Reif. "The Insurance Value of Medical Innovation." The Journal of Public Economics 145 (2017): 94-102.
/////////////////////////////////////

The Stata script "tables.do" produces the tables in the paper.
The script outputs its results to the /results folder.
